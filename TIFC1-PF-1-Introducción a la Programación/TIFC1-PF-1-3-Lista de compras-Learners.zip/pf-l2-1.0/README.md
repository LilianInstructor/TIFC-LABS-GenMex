# Instructions  
Write a program that takes the following inputs:
- list item 1
- list item 2
- list item 3

And then adds all three items to a list called `shopping_list`, *which contains no other items*. The input prompts don't matter but it should only ask for three items, one after the other.

Finally, you should print the shopping_list data structure.

**Remember: case matters!** This project will be automatically graded, and computers are very literal!